CREATE DATABASE PERSONAS;
USE Personas;
SELECT * FROM API_RES;
INSERT INTO API_RES(id,phone,email,name) VALUE ('1', '123456', 'user1@mail.com', 'user1');
//datos para crea la base de datos en MySQL
--y desde la BD se puede agregar de la siguiente manera